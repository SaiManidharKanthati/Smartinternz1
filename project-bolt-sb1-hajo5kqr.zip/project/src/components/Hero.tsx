import React from 'react';
import { ArrowRight, Truck, Shield, Clock } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-br from-emerald-600 via-emerald-700 to-emerald-800 text-white overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 py-16 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div>
              <div className="inline-flex items-center space-x-2 bg-emerald-500 bg-opacity-20 rounded-full px-4 py-2 mb-6">
                <span className="text-sm font-medium">🎉 Grand Opening Special</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Fresh Groceries
                <span className="block text-emerald-200">Delivered Fast</span>
              </h1>
              <p className="text-xl text-emerald-100 leading-relaxed mb-8">
                Get the freshest produce, premium meats, and everyday essentials delivered to your door. 
                Quality guaranteed, convenience delivered.
              </p>
            </div>

            {/* CTA buttons */}
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <button className="bg-white text-emerald-700 px-8 py-4 rounded-lg font-semibold hover:bg-emerald-50 transition-all duration-300 flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                <span>Shop Now</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-emerald-700 transition-all duration-300">
                Browse Categories
              </button>
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8">
              <div className="flex items-center space-x-3">
                <div className="bg-emerald-500 bg-opacity-20 rounded-full p-3">
                  <Truck className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-semibold">Free Delivery</div>
                  <div className="text-sm text-emerald-200">Orders over $50</div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="bg-emerald-500 bg-opacity-20 rounded-full p-3">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-semibold">Same Day</div>
                  <div className="text-sm text-emerald-200">Fast delivery</div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="bg-emerald-500 bg-opacity-20 rounded-full p-3">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-semibold">Fresh Guarantee</div>
                  <div className="text-sm text-emerald-200">Quality assured</div>
                </div>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="relative z-10">
              <img
                src="https://images.pexels.com/photos/1128678/pexels-photo-1128678.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Fresh groceries"
                className="w-full h-96 lg:h-[500px] object-cover rounded-2xl shadow-2xl"
              />
              
              {/* Floating cards */}
              <div className="absolute -top-4 -left-4 bg-white text-gray-900 rounded-xl p-4 shadow-xl">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="font-semibold text-sm">Fresh Daily</span>
                </div>
              </div>
              
              <div className="absolute -bottom-4 -right-4 bg-orange-500 text-white rounded-xl p-4 shadow-xl">
                <div className="text-center">
                  <div className="text-2xl font-bold">50%</div>
                  <div className="text-xs">OFF</div>
                </div>
              </div>
            </div>

            {/* Background decoration */}
            <div className="absolute top-8 right-8 w-64 h-64 bg-emerald-400 bg-opacity-20 rounded-full blur-3xl -z-10"></div>
            <div className="absolute bottom-8 left-8 w-48 h-48 bg-orange-400 bg-opacity-20 rounded-full blur-3xl -z-10"></div>
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" className="w-full h-12 fill-white">
          <path d="M0,64L48,69.3C96,75,192,85,288,80C384,75,480,53,576,48C672,43,768,53,864,64C960,75,1056,85,1152,80C1248,75,1344,53,1392,42.7L1440,32L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z"></path>
        </svg>
      </div>
    </section>
  );
};

export default Hero;