import React, { useState } from 'react';
import { Search, ShoppingCart, User, Menu, X, Heart, MapPin } from 'lucide-react';
import { CartItem } from '../types';

interface HeaderProps {
  cartItems: CartItem[];
  onCartToggle: () => void;
  onSearchChange: (query: string) => void;
  searchQuery: string;
}

const Header: React.FC<HeaderProps> = ({ cartItems, onCartToggle, onSearchChange, searchQuery }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLocationDropdownOpen, setIsLocationDropdownOpen] = useState(false);

  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cartItems.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  const navigation = [
    { name: 'Home', href: '#' },
    { name: 'Categories', href: '#' },
    { name: 'Deals', href: '#' },
    { name: 'Fresh Produce', href: '#' },
    { name: 'Pantry', href: '#' },
    { name: 'About', href: '#' }
  ];

  return (
    <header className="sticky top-0 z-50 bg-white shadow-lg border-b border-gray-100">
      {/* Top bar */}
      <div className="bg-emerald-600 text-white py-2">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <span>🚚 Free delivery on orders over $50</span>
            <span className="hidden md:inline">📞 Call us: (555) 123-4567</span>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              className="flex items-center space-x-1 hover:text-emerald-200 transition-colors"
              onClick={() => setIsLocationDropdownOpen(!isLocationDropdownOpen)}
            >
              <MapPin className="w-4 h-4" />
              <span>Deliver to 10001</span>
            </button>
            <span className="hidden md:inline">Help & Support</span>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="bg-emerald-600 text-white p-2 rounded-lg">
              <ShoppingCart className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">FreshMart</h1>
              <p className="text-xs text-gray-500">Fresh • Fast • Affordable</p>
            </div>
          </div>

          {/* Search bar */}
          <div className="hidden md:flex flex-1 max-w-2xl mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search for fresh groceries, organic products..."
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
              />
              <button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-emerald-600 text-white px-4 py-1.5 rounded-md hover:bg-emerald-700 transition-colors text-sm">
                Search
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            {/* Wishlist */}
            <button className="hidden md:flex items-center space-x-1 text-gray-600 hover:text-emerald-600 transition-colors">
              <Heart className="w-5 h-5" />
              <span className="text-sm">Wishlist</span>
            </button>

            {/* Account */}
            <button className="hidden md:flex items-center space-x-1 text-gray-600 hover:text-emerald-600 transition-colors">
              <User className="w-5 h-5" />
              <span className="text-sm">Account</span>
            </button>

            {/* Cart */}
            <button
              onClick={onCartToggle}
              className="relative flex items-center space-x-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 px-4 py-2 rounded-lg transition-colors"
            >
              <ShoppingCart className="w-5 h-5" />
              <div className="hidden md:block text-left">
                <div className="text-xs text-gray-600">Cart</div>
                <div className="text-sm font-semibold">${cartTotal.toFixed(2)}</div>
              </div>
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-semibold">
                  {cartItemCount}
                </span>
              )}
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden text-gray-600 hover:text-gray-900"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile search */}
        <div className="md:hidden mt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search groceries..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="hidden md:block border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-center space-x-8 py-3">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-gray-700 hover:text-emerald-600 font-medium transition-colors relative group"
              >
                {item.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-emerald-600 group-hover:w-full transition-all duration-300"></span>
              </a>
            ))}
          </div>
        </div>
      </nav>

      {/* Mobile navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100">
          <div className="px-4 py-3 space-y-3">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="block text-gray-700 hover:text-emerald-600 font-medium transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.name}
              </a>
            ))}
            <div className="pt-3 border-t border-gray-100 space-y-3">
              <a href="#" className="flex items-center space-x-2 text-gray-600">
                <Heart className="w-5 h-5" />
                <span>Wishlist</span>
              </a>
              <a href="#" className="flex items-center space-x-2 text-gray-600">
                <User className="w-5 h-5" />
                <span>Account</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;