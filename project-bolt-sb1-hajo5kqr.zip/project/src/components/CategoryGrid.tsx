import React from 'react';
import { Category } from '../types';

interface CategoryGridProps {
  categories: Category[];
  selectedCategory: string | null;
  onCategorySelect: (categoryId: string | null) => void;
}

const CategoryGrid: React.FC<CategoryGridProps> = ({ categories, selectedCategory, onCategorySelect }) => {
  return (
    <section className="py-8 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Shop by Category</h2>
          <p className="text-gray-600">Discover fresh, quality products in every category</p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 mb-6">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => onCategorySelect(category.id === selectedCategory ? null : category.id)}
              className={`group relative overflow-hidden rounded-xl p-4 text-center transition-all duration-300 hover:scale-105 hover:shadow-lg ${
                selectedCategory === category.id
                  ? 'ring-2 ring-emerald-500 bg-emerald-50'
                  : 'bg-white hover:bg-gray-50'
              }`}
            >
              <div className="mb-3">
                <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full text-2xl ${category.color} transition-transform group-hover:scale-110`}>
                  {category.icon}
                </div>
              </div>
              <h3 className="text-sm font-semibold text-gray-900 group-hover:text-emerald-600 transition-colors">
                {category.name}
              </h3>
              
              {/* Hover effect background */}
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-100/50 to-emerald-200/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10"></div>
            </button>
          ))}
        </div>

        {/* Active category indicator */}
        {selectedCategory && (
          <div className="flex items-center justify-center space-x-2 mb-4">
            <span className="text-sm text-gray-600">Showing:</span>
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-emerald-100 text-emerald-800">
              {categories.find(cat => cat.id === selectedCategory)?.name}
              <button
                onClick={() => onCategorySelect(null)}
                className="ml-2 text-emerald-600 hover:text-emerald-800"
              >
                ×
              </button>
            </span>
          </div>
        )}
      </div>
    </section>
  );
};

export default CategoryGrid;