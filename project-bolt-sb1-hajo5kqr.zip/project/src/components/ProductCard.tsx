import React from 'react';
import { ShoppingCart, Heart, Star, Leaf, Truck } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onProductClick: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onProductClick }) => {
  const discountedPrice = product.originalPrice ? product.originalPrice - product.price : 0;
  const discountPercentage = product.originalPrice ? Math.round((discountedPrice / product.originalPrice) * 100) : 0;

  return (
    <div className="group relative bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-100 hover:border-emerald-200">
      {/* Discount badge */}
      {product.discount && (
        <div className="absolute top-3 left-3 z-10 bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded-full">
          {product.discount}% OFF
        </div>
      )}

      {/* Organic badge */}
      {product.isOrganic && (
        <div className="absolute top-3 right-3 z-10 bg-green-100 text-green-600 rounded-full p-1.5">
          <Leaf className="w-4 h-4" />
        </div>
      )}

      {/* Wishlist button */}
      <button className="absolute top-3 right-12 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-white rounded-full p-2 shadow-md hover:bg-gray-50">
        <Heart className="w-4 h-4 text-gray-600 hover:text-red-500" />
      </button>

      {/* Product image */}
      <div 
        className="relative overflow-hidden cursor-pointer"
        onClick={() => onProductClick(product)}
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-300" />
      </div>

      {/* Product info */}
      <div className="p-4">
        {/* Brand */}
        {product.brand && (
          <p className="text-xs text-gray-500 uppercase tracking-wide font-medium mb-1">
            {product.brand}
          </p>
        )}

        {/* Product name */}
        <h3 
          className="font-semibold text-gray-900 mb-2 line-clamp-2 cursor-pointer hover:text-emerald-600 transition-colors"
          onClick={() => onProductClick(product)}
        >
          {product.name}
        </h3>

        {/* Weight/Unit */}
        {product.weight && (
          <p className="text-sm text-gray-500 mb-2">
            {product.weight} {product.unit && `/ ${product.unit}`}
          </p>
        )}

        {/* Rating */}
        <div className="flex items-center space-x-1 mb-3">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < Math.floor(product.rating)
                    ? 'text-yellow-400 fill-current'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-gray-600">
            {product.rating} ({product.reviewCount})
          </span>
        </div>

        {/* Price */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <span className="text-lg font-bold text-gray-900">
              ${product.price.toFixed(2)}
            </span>
            {product.originalPrice && (
              <span className="text-sm text-gray-500 line-through">
                ${product.originalPrice.toFixed(2)}
              </span>
            )}
          </div>
          {discountPercentage > 0 && (
            <span className="text-sm text-green-600 font-medium">
              Save ${discountedPrice.toFixed(2)}
            </span>
          )}
        </div>

        {/* Stock status */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-1">
            {product.inStock ? (
              <>
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-green-600 font-medium">In Stock</span>
              </>
            ) : (
              <>
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span className="text-sm text-red-600 font-medium">Out of Stock</span>
              </>
            )}
          </div>
          {product.stockCount < 10 && product.inStock && (
            <span className="text-sm text-orange-600 font-medium">
              Only {product.stockCount} left
            </span>
          )}
        </div>

        {/* Delivery info */}
        <div className="flex items-center space-x-1 mb-4 text-sm text-gray-600">
          <Truck className="w-4 h-4" />
          <span>Free delivery on orders over $50</span>
        </div>

        {/* Add to cart button */}
        <button
          onClick={() => onAddToCart(product)}
          disabled={!product.inStock}
          className={`w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
            product.inStock
              ? 'bg-emerald-600 hover:bg-emerald-700 text-white hover:shadow-md transform hover:-translate-y-0.5'
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
          }`}
        >
          <ShoppingCart className="w-4 h-4" />
          <span>{product.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
        </button>
      </div>
    </div>
  );
};

export default ProductCard;