import { Product, Category } from '../types';

export const categories: Category[] = [
  { id: 'fruits', name: 'Fresh Fruits', icon: '🍎', color: 'bg-red-100 text-red-600' },
  { id: 'vegetables', name: 'Vegetables', icon: '🥕', color: 'bg-green-100 text-green-600' },
  { id: 'dairy', name: 'Dairy & Eggs', icon: '🥛', color: 'bg-blue-100 text-blue-600' },
  { id: 'meat', name: 'Meat & Seafood', icon: '🥩', color: 'bg-pink-100 text-pink-600' },
  { id: 'bakery', name: 'Bakery', icon: '🍞', color: 'bg-yellow-100 text-yellow-600' },
  { id: 'pantry', name: 'Pantry Staples', icon: '🥫', color: 'bg-purple-100 text-purple-600' },
  { id: 'snacks', name: 'Snacks', icon: '🥨', color: 'bg-orange-100 text-orange-600' },
  { id: 'beverages', name: 'Beverages', icon: '🥤', color: 'bg-teal-100 text-teal-600' }
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Organic Bananas',
    description: 'Fresh, ripe organic bananas perfect for snacking or baking. Rich in potassium and natural sweetness.',
    price: 2.99,
    originalPrice: 3.49,
    image: 'https://images.pexels.com/photos/2872755/pexels-photo-2872755.jpeg?auto=compress&cs=tinysrgb&w=500',
    images: [
      'https://images.pexels.com/photos/2872755/pexels-photo-2872755.jpeg?auto=compress&cs=tinysrgb&w=500',
      'https://images.pexels.com/photos/61127/pexels-photo-61127.jpeg?auto=compress&cs=tinysrgb&w=500'
    ],
    category: 'fruits',
    rating: 4.8,
    reviewCount: 124,
    inStock: true,
    stockCount: 50,
    discount: 14,
    isOrganic: true,
    weight: '2 lbs',
    unit: 'bunch',
    brand: 'Organic Valley',
    nutritionInfo: {
      calories: 105,
      protein: '1.3g',
      carbs: '27g',
      fat: '0.4g'
    }
  },
  {
    id: '2',
    name: 'Fresh Strawberries',
    description: 'Sweet, juicy strawberries bursting with flavor. Perfect for desserts, smoothies, or eating fresh.',
    price: 4.99,
    image: 'https://images.pexels.com/photos/89778/strawberries-frisch-ripe-sweet-89778.jpeg?auto=compress&cs=tinysrgb&w=500',
    images: [
      'https://images.pexels.com/photos/89778/strawberries-frisch-ripe-sweet-89778.jpeg?auto=compress&cs=tinysrgb&w=500',
      'https://images.pexels.com/photos/1300975/pexels-photo-1300975.jpeg?auto=compress&cs=tinysrgb&w=500'
    ],
    category: 'fruits',
    rating: 4.6,
    reviewCount: 89,
    inStock: true,
    stockCount: 30,
    weight: '1 lb',
    unit: 'container',
    brand: 'Fresh Farm',
    nutritionInfo: {
      calories: 32,
      protein: '0.7g',
      carbs: '7.7g',
      fat: '0.3g'
    }
  },
  {
    id: '3',
    name: 'Organic Spinach',
    description: 'Fresh, tender organic spinach leaves. Rich in iron, vitamins, and perfect for salads or cooking.',
    price: 3.49,
    originalPrice: 3.99,
    image: 'https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'vegetables',
    rating: 4.7,
    reviewCount: 67,
    inStock: true,
    stockCount: 25,
    discount: 13,
    isOrganic: true,
    weight: '5 oz',
    unit: 'bag',
    brand: 'Green Goodness'
  },
  {
    id: '4',
    name: 'Premium Ground Beef',
    description: 'Fresh, high-quality ground beef from grass-fed cattle. Perfect for burgers, tacos, and more.',
    price: 8.99,
    image: 'https://images.pexels.com/photos/2280547/pexels-photo-2280547.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'meat',
    rating: 4.9,
    reviewCount: 156,
    inStock: true,
    stockCount: 15,
    weight: '1 lb',
    unit: 'package',
    brand: 'Prime Choice'
  },
  {
    id: '5',
    name: 'Artisan Sourdough Bread',
    description: 'Freshly baked artisan sourdough bread with a perfect crust and soft interior.',
    price: 5.49,
    image: 'https://images.pexels.com/photos/1028537/pexels-photo-1028537.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'bakery',
    rating: 4.8,
    reviewCount: 92,
    inStock: true,
    stockCount: 20,
    weight: '1.5 lbs',
    unit: 'loaf',
    brand: 'Artisan Bakery'
  },
  {
    id: '6',
    name: 'Farm Fresh Eggs',
    description: 'Free-range eggs from happy hens. Rich, creamy yolks perfect for any meal.',
    price: 4.29,
    image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'dairy',
    rating: 4.9,
    reviewCount: 203,
    inStock: true,
    stockCount: 40,
    weight: '12 eggs',
    unit: 'dozen',
    brand: 'Happy Hens Farm'
  },
  {
    id: '7',
    name: 'Organic Whole Milk',
    description: 'Rich, creamy organic whole milk from grass-fed cows. No hormones or antibiotics.',
    price: 3.99,
    image: 'https://images.pexels.com/photos/236010/pexels-photo-236010.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'dairy',
    rating: 4.7,
    reviewCount: 134,
    inStock: true,
    stockCount: 35,
    isOrganic: true,
    weight: '64 fl oz',
    unit: 'gallon',
    brand: 'Organic Valley'
  },
  {
    id: '8',
    name: 'Premium Olive Oil',
    description: 'Extra virgin olive oil from the finest olives. Perfect for cooking and dressing.',
    price: 12.99,
    originalPrice: 15.99,
    image: 'https://images.pexels.com/photos/33783/olive-oil-salad-dressing-cooking-olive.jpg?auto=compress&cs=tinysrgb&w=500',
    category: 'pantry',
    rating: 4.8,
    reviewCount: 78,
    inStock: true,
    stockCount: 22,
    discount: 19,
    weight: '16.9 fl oz',
    unit: 'bottle',
    brand: 'Mediterranean Gold'
  }
];